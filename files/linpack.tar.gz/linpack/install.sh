build_linpack() {
    set -e
    gcc -O2  -DDP -o linpack_dp linpack.c
    gcc -O2 -DSP -o linpack_sp linpack.c
}

build_linpack
